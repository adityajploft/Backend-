import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from '../models/User.js'; 

export const signup = async (req, res) => {
    const { name, email, password } = req.body;
    console.log("body values", name, email, password);

    const exist = await User.findOne({ email: email });

    if (exist) {
        return res.status(400).json({ msg: "user already exists with this email" });
    }

    const hashedPass = await bcrypt.hash(password, 10);

    const newUser = new User({
        name: name,
        email: email,
        password: hashedPass 
    });

    try {
        await newUser.save();
        return res.status(201).json({ msg: "User created successfully" });
    } catch (error) {
        return res.status(500).json({ msg: "Error saving user", error: error.message });
    }
};


export const login = async (req, res) => {
    const secretKey = process.env.JWT_SECRET;
    const { email, password } = req.body;

    const user = await User.findOne({ email: email });
    
    if (!user) {
        return res.status(400).json({ msg: "Invalid credentials" });
    }
    const match = await bcrypt.compare(password, user.password);

    if (match) {
        const userPayload = { 
            userId: user._id, 
            email: user.email,
            name: user.name
        };

        const token = jwt.sign(userPayload, secretKey, { expiresIn: '1h' });

        return res.status(200).json({ token: token, msg: "Login successful" });
    } else {
        return res.status(400).json({ msg: "Invalid credentials (password incorrect)" });
    }
};
